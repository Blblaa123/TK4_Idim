/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$IdPelanggan = $IdPenjualan = $IdPengguna = "";
$IdPelanggan_err = $IdPenjualan_err = $IdPengguna_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate IdPelanggan
    $input_IdPelanggan = trim($_POST["IdPelanggan"]);
    if(empty($input_IdPelanggan)){
        $IdPelanggan_err = "Masukan IdPelanggan.";
    } else{
        $IdPelanggan = $input_IdPelanggan;
    }

    // Validate Id Penjualan
    $input_IdPenjualan = trim($_POST["IdPenjualan"]);
    if(empty($input_IdPenjualan)){
        $IdPenjualan_err = "Masukan Id Penjualan.";
    } else{
        $IdPenjualan = $input_IdPenjualan;
    }

    // Validate IdPengguna
    $input_IdPengguna = trim($_POST["IdPengguna"]);
    if(empty($input_IdPengguna)){
        $IdPengguna_err = "Masukan IdPengguna.";
    } else{
        $IdPengguna = $input_IdPengguna;
    }
    
    
    
    // Check input errors before inserting in database
    if(empty($IdPelanggan_err) && empty($IdPenjualan_err) && empty($IdPengguna_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO Pelanggan (IdPelanggan, IdPenjualan, IdPengguna)"
                . "VALUES (?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "isi", $param_IdPelanggan, $param_IdPenjualan, $param_IdPengguna);

            // Set parameters
            $param_IdPelanggan = $IdPelanggan;
            $param_IdPenjualan = $IdPenjualan;
            $param_IdPengguna = $IdPengguna;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Tambah Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk menambahkan data Pelanggan ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                        <!--Input IdPelanggan-->
                        <div class="form-group <?php echo (!empty($IdPelanggan_err)) ? 'has-error' : ''; ?>">
                            <label>Id Pelanggan</label>
                            <input type="text" name="IdPelanggan" class="form-control" value="<?php echo $IdPelanggan; ?>">
                            <span class="help-block"><?php echo $IdPelanggan_err;?></span>
                        </div>
                        
                        <!--Input IdPenjualan-->
                        <div class="form-group <?php echo (!empty($IdPenjualan_err)) ? 'has-error' : ''; ?>">
                            <label>Id Penjualan</label>
                            <textarea name="IdPenjualan" class="form-control"><?php echo $IdPenjualan; ?></textarea>
                            <span class="help-block"><?php echo $IdPenjualan_err;?></span>
                        </div>
                        
                        <!--Input IdPengguna-->
                        <div class="form-group <?php echo (!empty($IdPengguna_err)) ? 'has-error' : ''; ?>">
                            <label>Id Pengguna</label>
                            <textarea name="IdPengguna" class="form-control"><?php echo $IdPengguna; ?></textarea>
                            <span class="help-block"><?php echo $IdPengguna_err;?></span>
                        </div>
                                             
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
