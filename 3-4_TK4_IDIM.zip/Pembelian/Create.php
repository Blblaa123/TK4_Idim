/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$IdPembelian = $JumlahPembelian = $HargaBeli = $IdBarang = "";
$IdPembelian_err = $JumlahPembelian_err = $HargaBeli_err = $IdBarang_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate IdPembelian
    $input_IdPembelian = trim($_POST["IdPembelian"]);
    if(empty($input_IdPembelian)){
        $IdPembelian_err = "Masukan IdPembelian.";
    } else{
        $IdPembelian = $input_IdPembelian;
    }

    // Validate JumlahPembelian
    $input_JumlahPembelian = trim($_POST["JumlahPembelian"]);
    if(empty($input_JumlahPembelian)){
        $JumlahPembelian_err = "Masukan JumlahPembelian.";
    } else{
        $JumlahPembelian = $input_JumlahPembelian;
    }

    // Validate HargaBeli
    $input_HargaBeli = trim($_POST["HargaBeli"]);
    if(empty($input_HargaBeli)){
        $HargaBeli_err = "Masukan HargaBeli barang.";
    } else{
        $HargaBeli = $input_HargaBeli;
    }
    
    // Validate IdBarang
    $input_IdBarang = trim($_POST["IdBarang"]);
    if(empty($input_IdBarang)){
        $IdBarang_err = "Masukan IdBarang.";
    } else{
        $IdBarang = $input_IdBarang;
    }
 
    
    // Check input errors before inserting in database
    if(empty($IdPembelian_err) && empty($JumlahPembelian_err)&& empty($HargaBeli_err) && empty($IdBarang_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO Pembelian (IdPembelian, JumlahPembelian, HargaBeli, IdBarang)"
                . "VALUES (?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "siis", $param_IdPembelian,
                    $param_JumlahPembelian, $param_HargaBeli, $param_IdBarang);

            // Set parameters
            $param_IdPembelian = $IdPembelian;
            $param_JumlahPembelian = $JumlahPembelian;
            $param_HargaBeli = $HargaBeli;
            $param_IdBarang = $IdBarang;


            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Tambah Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk menambahkan data Pembelian ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                        <!--Input IdPembelian-->
                        <div class="form-group <?php echo (!empty($IdPembelian_err)) ? 'has-error' : ''; ?>">
                            <label>Id Pembelian</label>
                            <input type="text" name="IdPembelian" class="form-control" value="<?php echo $IdPembelian; ?>">
                            <span class="help-block"><?php echo $IdPembelian_err;?></span>
                        </div>
                        
                        <!--Input JumlahPembelian-->
                        <div class="form-group <?php echo (!empty($JumlahPembelian_err)) ? 'has-error' : ''; ?>">
                            <label>Jumlah Pembelian</label>
                            <input type="text" name="JumlahPembelian" class="form-control" value="<?php echo $JumlahPembelian; ?>">
                            <span class="help-block"><?php echo $JumlahPembelian_err;?></span>
                        </div>
                        
                        <!--Input HargaBeli-->
                        <div class="form-group <?php echo (!empty($HargaBeli_err)) ? 'has-error' : ''; ?>">
                            <label>Harga Beli</label>
                            <input type="text" name="HargaBeli" class="form-control" value="<?php echo $HargaBeli; ?>">
                            <span class="help-block"><?php echo $HargaBeli_err;?></span>
                        </div>
                        
                        <!--Input IdBarang-->
                        <div class="form-group <?php echo (!empty($IdBarang_err)) ? 'has-error' : ''; ?>">
                            <label>Id Barang</label>
                            <textarea name="IdBarang" class="form-control"><?php echo $IdBarang; ?></textarea>
                            <span class="help-block"><?php echo $IdBarang_err;?></span>
                        </div>
                                             
                        
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

