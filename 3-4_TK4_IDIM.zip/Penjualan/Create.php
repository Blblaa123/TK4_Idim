/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$IdPenjualan = $JumlahPenjualan = $HargaJual = $IdBarang = "";
$IdPenjualan_err = $JumlahPenjualan_err = $HargaJual_err = $IdBarang_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate IdPenjualan
    $input_IdPenjualan = trim($_POST["IdPenjualan"]);
    if(empty($input_IdPenjualan)){
        $IdPenjualan_err = "Masukan IdPenjualan.";
    } else{
        $IdPenjualan = $input_IdPenjualan;
    }

    // Validate JumlahPenjualan
    $input_JumlahPenjualan = trim($_POST["JumlahPenjualan"]);
    if(empty($input_JumlahPenjualan)){
        $JumlahPenjualan_err = "Masukan JumlahPenjualan.";
    } else{
        $JumlahPenjualan = $input_JumlahPenjualan;
    }

    // Validate HargaJual
    $input_HargaJual = trim($_POST["HargaJual"]);
    if(empty($input_HargaJual)){
        $HargaJual_err = "Masukan HargaJual barang.";
    } else{
        $HargaJual = $input_HargaJual;
    }
    
    // Validate IdBarang
    $input_IdBarang = trim($_POST["IdBarang"]);
    if(empty($input_IdBarang)){
        $IdBarang_err = "Masukan IdBarang.";
    } else{
        $IdBarang = $input_IdBarang;
    }
 
    
    // Check input errors before inserting in database
    if(empty($IdPenjualan_err) && empty($JumlahPenjualan_err)&& empty($HargaJual_err) && empty($IdBarang_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO Penjualan (IdPenjualan, JumlahPenjualan, HargaJual, IdBarang)"
                . "VALUES (?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "siis", $param_IdPenjualan,
                    $param_JumlahPenjualan, $param_HargaJual, $param_IdBarang);

            // Set parameters
            $param_IdPenjualan = $IdPenjualan;
            $param_JumlahPenjualan = $JumlahPenjualan;
            $param_HargaJual = $HargaJual;
            $param_IdBarang = $IdBarang;


            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Tambah Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk menambahkan data Penjualan ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                        <!--Input IdPenjualan-->
                        <div class="form-group <?php echo (!empty($IdPenjualan_err)) ? 'has-error' : ''; ?>">
                            <label>Id Penjualan</label>
                            <input type="text" name="IdPenjualan" class="form-control" value="<?php echo $IdPenjualan; ?>">
                            <span class="help-block"><?php echo $IdPenjualan_err;?></span>
                        </div>
                        
                        <!--Input JumlahPenjualan-->
                        <div class="form-group <?php echo (!empty($JumlahPenjualan_err)) ? 'has-error' : ''; ?>">
                            <label>Jumlah Penjualan</label>
                            <input type="text" name="JumlahPenjualan" class="form-control" value="<?php echo $JumlahPenjualan; ?>">
                            <span class="help-block"><?php echo $JumlahPenjualan_err;?></span>
                        </div>
                        
                        <!--Input HargaJual-->
                        <div class="form-group <?php echo (!empty($HargaJual_err)) ? 'has-error' : ''; ?>">
                            <label>Harga Jual</label>
                            <input type="text" name="HargaJual" class="form-control" value="<?php echo $HargaJual; ?>">
                            <span class="help-block"><?php echo $HargaJual_err;?></span>
                        </div>
                        
                        <!--Input IdBarang-->
                        <div class="form-group <?php echo (!empty($IdBarang_err)) ? 'has-error' : ''; ?>">
                            <label>Id Barang</label>
                            <textarea name="IdBarang" class="form-control"><?php echo $IdBarang; ?></textarea>
                            <span class="help-block"><?php echo $IdBarang_err;?></span>
                        </div>
                                             
                        
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

