/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$IdBarang = $NamaBarang = $Keterangan = $Satuan = $IdPengguna = "";
$IdBarang_err = $NamaBarang_err = $Keterangan_err = $Satuan_err = $IdPengguna_err = "";

 
// Processing form data when form is submitted
if(isset($_POST["IdBarang"]) && !empty($_POST["IdBarang"])){
    // Get hidden input value
    $IdBarang = $_POST["IdBarang"];
    
    // Validate NamaBarang
    $input_NamaBarang = trim($_POST["NamaBarang"]);
    if(empty($input_NamaBarang)){
        $NamaBarang_err = "Masukan nama barang.";
    } else{
        $NamaBarang = $input_NamaBarang;
    }

    // Validate Keterangan
    $input_Keterangan = trim($_POST["Keterangan"]);
    if(empty($input_Keterangan)){
        $Keterangan_err = "Masukan keterangan barang.";
    } else{
        $Keterangan = $input_Keterangan;
    }

    // Validate Satuan
    $input_Satuan = trim($_POST["Satuan"]);
    if(empty($input_Satuan)){
        $Satuan_err = "Masukan Satuan barang.";
    } else{
        $Satuan = $input_Satuan;
    }
    
    // Validate IdPengguna
    $input_IdPengguna = trim($_POST["IdPengguna"]);
    if(empty($input_IdPengguna)){
        $IdPengguna_err = "Masukan IdPengguna.";
    } else{
        $IdPengguna = $input_IdPengguna;
    }
    
    // Check input errors before inserting in database
    if(empty($NamaBarang_err) && empty($Keterangan_err)&& empty($Satuan_err)
            && empty($IdPengguna_err)){
        // Prepare an update statement
        $sql = "UPDATE employees SET NamaBarang=?, Keterangan=?, Satuan=?,"
                . "IdPengguna=? WHERE IdBarang=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssi", $param_IdBarang, $param_NamaBarang,
                    $param_Keterangan, $param_Satuan, $param_IdPengguna);

            // Set parameters
            $param_IdBarang = $IdBarang;
            $param_NamaBarang = $NamaBarang;
            $param_Keterangan = $Keterangan;
            $param_Satuan = $Satuan;
            $param_IdPengguna = $IdPengguna;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["IdBarang"]) && !empty(trim($_GET["IdBarang"]))){
        // Get URL parameter
        $IdBarang =  trim($_GET["IdBarang"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM Barang WHERE IdBarang = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_IdBarang);
            
            // Set parameters
            $param_IdBarang = $IdBarang;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $NamaBarang = $row["NamaBarang"];
                    $Keterangan = $row["Keterangan"];
                    $Satuan = $row["Satuan"];
                    $IdPengguna = $row["IdPengguna"];
                    
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($link);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk mengupdate data barang ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        
                        <!--Input NamaBarang-->
                        <div class="form-group <?php echo (!empty($NamaBarang_err)) ? 'has-error' : ''; ?>">
                            <label>Nama Barang</label>
                            <textarea name="NamaBarang" class="form-control"><?php echo $NamaBarang; ?></textarea>
                            <span class="help-block"><?php echo $NamaBarang_err;?></span>
                        </div>
                        
                        <!--Input Keterangan-->
                        <div class="form-group <?php echo (!empty($Keterangan_err)) ? 'has-error' : ''; ?>">
                            <label>Keterangan</label>
                            <input type="text" name="Keterangan" class="form-control" value="<?php echo $Keterangan; ?>">
                            <span class="help-block"><?php echo $Keterangan_err;?></span>
                        </div>
                        
                        <!--Input Satuan-->
                        <div class="form-group <?php echo (!empty($Satuan_err)) ? 'has-error' : ''; ?>">
                            <label>Satuan</label>
                            <input type="text" name="Satuan" class="form-control" value="<?php echo $Satuan; ?>">
                            <span class="help-block"><?php echo $Satuan_err;?></span>
                        </div>
                        
                        <!--Input IdPengguna-->
                        <div class="form-group <?php echo (!empty($IdPengguna_err)) ? 'has-error' : ''; ?>">
                            <label>Id Pengguna</label>
                            <textarea name="IdPengguna" class="form-control"><?php echo $IdPengguna; ?></textarea>
                            <span class="help-block"><?php echo $IdPengguna_err;?></span>
                        </div>         
                        
                        <input type="hidden" name="IdBarang" value="<?php echo $IdBarang; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
