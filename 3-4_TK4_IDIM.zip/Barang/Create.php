/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$IdBarang = $NamaBarang = $Keterangan = $Satuan = $IdPengguna = "";
$IdBarang_err = $NamaBarang_err = $Keterangan_err = $Satuan_err = $IdPengguna_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate IdBarang
    $input_IdBarang = trim($_POST["IdBarang"]);
    if(empty($input_IdBarang)){
        $IdBarang_err = "Masukan IdBarang.";
    } else{
        $IdBarang = $input_IdBarang;
    }

    // Validate NamaBarang
    $input_NamaBarang = trim($_POST["NamaBarang"]);
    if(empty($input_NamaBarang)){
        $NamaBarang_err = "Masukan Nama Barang.";
    } else{
        $NamaBarang = $input_NamaBarang;
    }

    // Validate Keterangan
    $input_Keterangan = trim($_POST["Keterangan"]);
    if(empty($input_Keterangan)){
        $Keterangan_err = "Masukan Keterangan.";
    } else{
        $Keterangan = $input_Keterangan;
    }

    // Validate Satuan
    $input_Satuan = trim($_POST["Satuan"]);
    if(empty($input_Satuan)){
        $Satuan_err = "Masukan Satuan barang.";
    } else{
        $Satuan = $input_Satuan;
    }
    
    // Validate IdPengguna
    $input_IdPengguna = trim($_POST["IdPengguna"]);
    if(empty($input_IdPengguna)){
        $IdPengguna_err = "Masukan IdPengguna.";
    } else{
        $IdPengguna = $input_IdPengguna;
    }
 
    
    // Check input errors before inserting in database
    if(empty($IdBarang_err) && empty($NamaBarang_err) && empty($Keterangan_err)&&
       empty($Satuan_err) && empty($IdPengguna_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO Barang (IdBarang, NamaBarang, Keterangan, Satuan, IdPengguna)"
                . "VALUES (?, ?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssi", $param_IdBarang, $param_NamaBarang,
                    $param_Keterangan, $param_Satuan, $param_IdPengguna);

            // Set parameters
            $param_IdBarang = $IdBarang;
            $param_NamaBarang = $NamaBarang;
            $param_Keterangan = $Keterangan;
            $param_Satuan = $Satuan;
            $param_IdPengguna = $IdPengguna;


            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Tambah Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk menambahkan data barang ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                        <!--Input IdBarang-->
                        <div class="form-group <?php echo (!empty($IdBarang_err)) ? 'has-error' : ''; ?>">
                            <label>Id Barang</label>
                            <input type="text" name="IdBarang" class="form-control" value="<?php echo $IdBarang; ?>">
                            <span class="help-block"><?php echo $IdBarang_err;?></span>
                        </div>
                        
                        <!--Input NamaBarang-->
                        <div class="form-group <?php echo (!empty($NamaBarang_err)) ? 'has-error' : ''; ?>">
                            <label>Nama Barang</label>
                            <textarea name="NamaBarang" class="form-control"><?php echo $NamaBarang; ?></textarea>
                            <span class="help-block"><?php echo $NamaBarang_err;?></span>
                        </div>
                        
                        <!--Input Keterangan-->
                        <div class="form-group <?php echo (!empty($Keterangan_err)) ? 'has-error' : ''; ?>">
                            <label>Keterangan</label>
                            <input type="text" name="Keterangan" class="form-control" value="<?php echo $Keterangan; ?>">
                            <span class="help-block"><?php echo $Keterangan_err;?></span>
                        </div>
                        
                        <!--Input Satuan-->
                        <div class="form-group <?php echo (!empty($Satuan_err)) ? 'has-error' : ''; ?>">
                            <label>Satuan</label>
                            <input type="text" name="Satuan" class="form-control" value="<?php echo $Satuan; ?>">
                            <span class="help-block"><?php echo $Satuan_err;?></span>
                        </div>
                        
                        <!--Input IdPengguna-->
                        <div class="form-group <?php echo (!empty($IdPengguna_err)) ? 'has-error' : ''; ?>">
                            <label>Id Pengguna</label>
                            <textarea name="IdPengguna" class="form-control"><?php echo $IdPengguna; ?></textarea>
                            <span class="help-block"><?php echo $IdPengguna_err;?></span>
                        </div>
                                             
                        
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>