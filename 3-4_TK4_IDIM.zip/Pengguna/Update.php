/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$Password = $NamaDepan = $NamaBelakang = $NoHP = $Alamat = $IdAkses = "";
$Password_err = $NamaDepan_err = $NamaBelakang_err = $NoHP_err = $Alamat_err = $IdAkses_err = "";

 
// Processing form data when form is submitted
if(isset($_POST["IdPengguna"]) && !empty($_POST["IdPengguna"])){
    // Get hidden input value
    $IdPengguna = $_POST["IdPengguna"];
    
    // Validate Password
    $input_Password = trim($_POST["Password"]);
    if(empty($input_Password)){
        $Password_err = "Masukan Password.";
    } else{
        $Password = $input_Password;
    }

    // Validate NamaDepan
    $input_NamaDepan = trim($_POST["NamaDepan"]);
    if(empty($input_NamaDepan)){
        $NamaDepan_err = "Masukan nama depan Anda.";
    } elseif(!filter_var($input_NamaDepan, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $NamaDepan = "Masukan nama depan Anda dengan benar.";
    } else{
        $NamaDepan = $input_NamaDepan;
    }

    // Validate NamaBelakang
    $input_NamaBelakang = trim($_POST["NamaBelakang"]);
    if(empty($input_NamaBelakang)){
        $NamaBelakang_err = "Masukan nama belakang Anda.";
    } elseif(!filter_var($input_NamaBelakang, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $NamaBelakang = "Masukan nama belakang Anda dengan benar.";
    } else{
        $NamaBelakang = $input_NamaBelakang;
    }
    
    // Validate NoHP
    $input_NoHP = trim($_POST["NoHP"]);
    if(empty($input_NoHP)){
        $NoHP_err = "Masukan nomor HP.";
    } else{
        $NoHP = $input_NoHP;
    }
    
    // Validate Alamat
    $input_Alamat = trim($_POST["Alamat"]);
    if(empty($input_Alamat)){
        $Alamat_err = "Masukan alamat Anda.";
    } else{
        $Alamat = $input_Alamat;
    }
    
     // Validate IdAkses
    $input_IdAkses = trim($_POST["IdAkses"]);
    if(empty($input_IdAkses)){
        $IdAkses_err = "Masukan Id Akses Anda.";
    } else{
        $IdAkses = $input_IdAkses;
    }
    
    // Check input errors before inserting in database
    if(empty($Password_err) && empty($NamaDepan_err)&& empty($NamaBelakang_err)
            && empty($NoHP_err) && empty($Alamat_err) && empty($IdAkses_err)){
        // Prepare an update statement
        $sql = "UPDATE Pengguna SET Password=?, NamaDepan=?, NamaBelakang=?,"
                . "NoHP=?, Alamat=?, IdAkses=? WHERE IdPengguna=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "isssisi", $param_IdPengguna, $param_Password,
                    $param_NamaDepan, $param_NamaBelakang, $param_NoHP, $param_Alamat, $param_IdAkses);

            // Set parameters
            $param_IdPengguna = $IdPengguna;
            $param_Password = $Password;
            $param_NamaDepan = $NamaDepan;
            $param_NamaBelakang = $NamaBelakang;
            $param_NoHP = $NoHP;
            $param_Alamat = $Alamat;
            $param_IdAkses = $IdAkses;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["IdPengguna"]) && !empty(trim($_GET["IdPengguna"]))){
        // Get URL parameter
        $IdPengguna =  trim($_GET["IdPengguna"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM Pengguna WHERE IdPengguna = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_IdPengguna);
            
            // Set parameters
            $param_IdPengguna = $IdPengguna;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $Password = $row["Password"];
                    $NamaDepan = $row["NamaDepan"];
                    $NamaBelakang = $row["NamaBelakang"];
                    $NoHP = $row["NoHP"];
                    $Alamat = $row["Alamat"];
                    $IdAkses = $row["IdAkses"];
                    
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($link);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk mengupdate data pengguna ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        
                        <!--Input Password-->
                        <div class="form-group <?php echo (!empty($Password_err)) ? 'has-error' : ''; ?>">
                            <label>Password</label>
                            <textarea name="Password" class="form-control"><?php echo $Password; ?></textarea>
                            <span class="help-block"><?php echo $Password_err;?></span>
                        </div>
                        
                        <!--Input NamaDepan-->
                        <div class="form-group <?php echo (!empty($NamaDepan_err)) ? 'has-error' : ''; ?>">
                            <label>Nama Depan</label>
                            <input type="text" name="NamaDepan" class="form-control" value="<?php echo $NamaDepan; ?>">
                            <span class="help-block"><?php echo $NamaDepan_err;?></span>
                        </div>
                        
                        <!--Input NamaBelakang-->
                        <div class="form-group <?php echo (!empty($NamaBelakang_err)) ? 'has-error' : ''; ?>">
                            <label>Nama Belakang</label>
                            <input type="text" name="NamaBelakang" class="form-control" value="<?php echo $NamaBelakang; ?>">
                            <span class="help-block"><?php echo $NamaBelakang_err;?></span>
                        </div>
                        
                        <!--Input NoHP-->
                        <div class="form-group <?php echo (!empty($NoHP_err)) ? 'has-error' : ''; ?>">
                            <label>Nomor HP</label>
                            <textarea name="NoHP" class="form-control"><?php echo $NoHP; ?></textarea>
                            <span class="help-block"><?php echo $NoHP_err;?></span>
                        </div>
                                             
                        <!--Input Alamat-->
                        <div class="form-group <?php echo (!empty($Alamat_err)) ? 'has-error' : ''; ?>">
                            <label>Alamat</label>
                            <textarea name="Alamat" class="form-control"><?php echo $Alamat; ?></textarea>
                            <span class="help-block"><?php echo $Alamat_err;?></span>
                        </div>
                        
                        <!--Input IdAkses-->
                        <div class="form-group <?php echo (!empty($IdAkses_err)) ? 'has-error' : ''; ?>">
                            <label>Id Akses</label>
                            <textarea name="IdAkses" class="form-control"><?php echo $IdAkses; ?></textarea>
                            <span class="help-block"><?php echo $IdAkses_err;?></span>
                        </div>
                        
                        <input type="hidden" name="IdPengguna" value="<?php echo $IdPengguna; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>

