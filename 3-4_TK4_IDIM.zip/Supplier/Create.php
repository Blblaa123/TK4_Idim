/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$IdSupplier = $IdPembelian = $IdPengguna = "";
$IdSupplier_err = $IdPembelian_err = $IdPengguna_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate IdSupplier
    $input_IdSupplier = trim($_POST["IdSupplier"]);
    if(empty($input_IdSupplier)){
        $IdSupplier_err = "Masukan IdSupplier.";
    } else{
        $IdSupplier = $input_IdSupplier;
    }

    // Validate Id Pembelian
    $input_IdPembelian = trim($_POST["IdPembelian"]);
    if(empty($input_IdPembelian)){
        $IdPembelian_err = "Masukan Id Pembelian.";
    } else{
        $IdPembelian = $input_IdPembelian;
    }

    // Validate IdPengguna
    $input_IdPengguna = trim($_POST["IdPengguna"]);
    if(empty($input_IdPengguna)){
        $IdPengguna_err = "Masukan IdPengguna.";
    } else{
        $IdPengguna = $input_IdPengguna;
    }
    
    
    
    // Check input errors before inserting in database
    if(empty($IdSupplier_err) && empty($IdPembelian_err) && empty($IdPengguna_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO Supplier (IdSupplier, IdPembelian, IdPengguna)"
                . "VALUES (?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "isi", $param_IdSupplier, $param_IdPembelian, $param_IdPengguna);

            // Set parameters
            $param_IdSupplier = $IdSupplier;
            $param_IdPembelian = $IdPembelian;
            $param_IdPengguna = $IdPengguna;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Tambah Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk menambahkan data Supplier ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                        <!--Input IdSupplier-->
                        <div class="form-group <?php echo (!empty($IdSupplier_err)) ? 'has-error' : ''; ?>">
                            <label>Id Supplier</label>
                            <input type="text" name="IdSupplier" class="form-control" value="<?php echo $IdSupplier; ?>">
                            <span class="help-block"><?php echo $IdSupplier_err;?></span>
                        </div>
                        
                        <!--Input IdPembelian-->
                        <div class="form-group <?php echo (!empty($IdPembelian_err)) ? 'has-error' : ''; ?>">
                            <label>Id Pembelian</label>
                            <textarea name="IdPembelian" class="form-control"><?php echo $IdPembelian; ?></textarea>
                            <span class="help-block"><?php echo $IdPembelian_err;?></span>
                        </div>
                        
                        <!--Input IdPengguna-->
                        <div class="form-group <?php echo (!empty($IdPengguna_err)) ? 'has-error' : ''; ?>">
                            <label>Id Pengguna</label>
                            <textarea name="IdPengguna" class="form-control"><?php echo $IdPengguna; ?></textarea>
                            <span class="help-block"><?php echo $IdPengguna_err;?></span>
                        </div>
                                             
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
