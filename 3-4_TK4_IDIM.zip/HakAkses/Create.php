/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$IdAkses = $NamaAkses = $Keterangan = "";
$IdAkses_err = $NamaAkses_err = $Keterangan_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate IdAkses
    $input_IdAkses = trim($_POST["IdAkses"]);
    if(empty($input_IdAkses)){
        $IdAkses_err = "Masukan IdAkses.";
    } else{
        $IdAkses = $input_IdAkses;
    }

    // Validate Nama Akses
    $input_NamaAkses = trim($_POST["NamaAkses"]);
    if(empty($input_NamaAkses)){
        $NamaAkses_err = "Masukan Nama Akses.";
    } else{
        $NamaAkses = $input_NamaAkses;
    }

    // Validate Keterangan
    $input_Keterangan = trim($_POST["Keterangan"]);
    if(empty($input_Keterangan)){
        $Keterangan_err = "Masukan Keterangan.";
    } else{
        $Keterangan = $input_Keterangan;
    }
    
    
    
    // Check input errors before inserting in database
    if(empty($IdAkses_err) && empty($NamaAkses_err) && empty($Keterangan_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO HakAkses (IdAkses, NamaAkses, Keterangan)"
                . "VALUES (?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "iss", $param_IdAkses, $param_NamaAkses, $param_Keterangan);

            // Set parameters
            $param_IdAkses = $IdAkses;
            $param_NamaAkses = $NamaAkses;
            $param_Keterangan = $Keterangan;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Tambah Record</h2>
                    </div>
                    <p>Silahkan isi form di bawah ini kemudian submit untuk menambahkan data Hak Akses ke dalam database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                        <!--Input IdAkses-->
                        <div class="form-group <?php echo (!empty($IdAkses_err)) ? 'has-error' : ''; ?>">
                            <label>Id Akses</label>
                            <input type="text" name="IdAkses" class="form-control" value="<?php echo $IdAkses; ?>">
                            <span class="help-block"><?php echo $IdAkses_err;?></span>
                        </div>
                        
                        <!--Input NamaAkses-->
                        <div class="form-group <?php echo (!empty($NamaAkses_err)) ? 'has-error' : ''; ?>">
                            <label>Nama Akses</label>
                            <textarea name="NamaAkses" class="form-control"><?php echo $NamaAkses; ?></textarea>
                            <span class="help-block"><?php echo $NamaAkses_err;?></span>
                        </div>
                        
                        <!--Input Keterangan-->
                        <div class="form-group <?php echo (!empty($Keterangan_err)) ? 'has-error' : ''; ?>">
                            <label>Keterangan</label>
                            <textarea name="Keterangan" class="form-control"><?php echo $Keterangan; ?></textarea>
                            <span class="help-block"><?php echo $Keterangan_err;?></span>
                        </div>
                                             
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>